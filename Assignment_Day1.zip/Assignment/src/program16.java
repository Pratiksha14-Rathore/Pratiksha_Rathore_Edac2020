
public class program16 {

	public static void main(String[] args) {
	        System.out.println(" +\"\"\"\"\"+ ");
	        System.out.println("[| o o |]");
	        System.out.println(" |  ^  | ");
	        System.out.println(" | '-' | ");
	        System.out.println(" +-----+ ");
	    }
		

	}


