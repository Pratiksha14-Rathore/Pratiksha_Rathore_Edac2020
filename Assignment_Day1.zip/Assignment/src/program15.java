
public class program15 {

	public static void main(String[] args) {
		int a, b, temp;
		   a = 10;
		   b = 22;
		   System.out.println("Numbers : a, b = "+a+", "+ + b);
		   temp = a;
		   a = b;
		   b = temp;   
		   System.out.println("swapping of Two Numbers : a, b = "+a+", "+ + b);
		 }
 }



