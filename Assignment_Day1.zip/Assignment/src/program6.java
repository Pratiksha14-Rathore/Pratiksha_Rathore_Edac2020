import java.util.Scanner;

public class program6 {

	public static void main(String[] args) {
		
			  Scanner sc = new Scanner(System.in);
			   
			  System.out.print("First number: ");
			  int a = sc.nextInt();
			   
			  System.out.print("Second number: ");
			  int b = sc.nextInt();
			   
			 
			  System.out.println(a + " + " + b + " = " + 
			  (a + b));
			   
			  System.out.println(a + " - " + b + " = " + 
			  (a - b));
			   
			  System.out.println(a + " x " + b + " = " + 
			  (a * b));
			   
			  System.out.println(a + " / " + b + " = " + 
			  (a / b));
			 
			  System.out.println(a + " mod " + b + " = " + 
			  (a % b));
			 }
			 
			
}
