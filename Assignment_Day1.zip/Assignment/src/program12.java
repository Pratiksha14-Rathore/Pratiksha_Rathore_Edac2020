import java.util.Scanner;

public class program12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		   
		  System.out.print("First number: ");
		  int a = sc.nextInt();
		   
		  System.out.print("Second number: ");
		  int b = sc.nextInt();
		   
		  System.out.print("Third number: ");
		  int c = sc.nextInt();
		  
		  System.out.println("Average of Three numbers is: " + 
		  (a + b + c )/ 3);
		}
				
	}


