import java.util.Scanner;

public class program19 {

	public static void main(String[] args) {
	int number,i=0;
	int Binary[]=new int[100];
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Decimal Number:");
	number=sc.nextInt();
	while(number!=0)
	{
		Binary[i]=number%2;
		number=number/2;
		i++;
	}
	System.out.println("Binary Value is:");
	for(int j=i-1;j>=0;j--)
	{
		System.out.println(""+Binary[j]);
		
	}
	}

}
