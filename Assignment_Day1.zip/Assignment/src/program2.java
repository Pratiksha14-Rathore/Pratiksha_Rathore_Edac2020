import java.util.Scanner;

public class program2 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Fisrt Number:");
	int num1=sc.nextInt();
	System.out.println("Second Number:");
    int num2=sc.nextInt();
    System.out.println("The sum of the Numbers is "+(num1+num2));
	}

}
