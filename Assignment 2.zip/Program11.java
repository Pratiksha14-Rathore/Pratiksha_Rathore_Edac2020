class Program11
{
 public static void main(String args[])
 { 
   int i,row=7,space,k=0;
   for(i=1;i<=row;i++)
   {
   for(space=1;space<=(row-i);space++)
   {
    System.out.print(" ");
   }
    while(k!=(1*i-1))
    {
    System.out.print(" *");
    k++;
}
k=0;
System.out.println();
}
}
}
