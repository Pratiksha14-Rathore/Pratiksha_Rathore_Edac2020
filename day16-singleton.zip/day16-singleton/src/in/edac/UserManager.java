package in.edac;

//this is non entity class
public class UserManager {
	private static  UserManager instance;
	
	private UserManager() {
		super();
	}
	//we can create object within the class itself means in the same class
  public static UserManager createObject() {
	   UserManager instance =new UserManager();
	   return instance;
  }
  
  //Another method 
  public static UserManager getInstance() {
	  if(instance==null) {
		  instance =new UserManager();
	  }
	 
	  return instance;
  }
}
