package in.edac;

public class SingletoneDemo {
	public static void main(String args[]) {
     System.out.println("Hellooooo");
     
     //Creating instance of class of Nonentity class
     //or for a one particular class we can create any number of object
     //whenever we use new keyword we call constructur function new UserManger();
     //whenevr we dont useconstrucur jvm by default create a constructur 
     //our agenda is to make singletone pattern by using pattern 

   UserDao ref1=UserDao.getIntance();
   System.out.println(ref1);
   
   UserDao ref2=UserDao.getIntance();
   System.out.println(ref2);

     
     
}
}
