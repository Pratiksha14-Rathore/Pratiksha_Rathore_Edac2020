que5.
package Stringpackage;

public class Stringlengthdemo {
	public static void stringlenofwords(String s)
	{
		char[] ch=s.toCharArray();
		int length=ch.length;
		for(int i=0;i<length;i++)
		{
			String str="";
		
		while(i<length && ch[i]!=' ')
		{
			str=str+ch[i];
			i++;
		}
		if(str.length()>0)
		{
			System.out.println(str+"=>"+str.length());
		}
	   }
	}
	public static void main(String[]args)
	{
		String s="I am a java programmer";
		stringlenofwords(s);
	}

}
