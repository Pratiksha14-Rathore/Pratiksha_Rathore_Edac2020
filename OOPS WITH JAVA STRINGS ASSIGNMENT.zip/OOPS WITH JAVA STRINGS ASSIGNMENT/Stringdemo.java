que1.
package Stringpackage;

public class Stringdemo {

	public static void main(String[] args) {
		String str="Hello world 37 1!";
		String lcase=str.toLowerCase();
		System.out.println(lcase);
		char[] ch=lcase.toCharArray();
		int len=ch.length;
		System.out.println("length is "+len);
		int vowelcnt=0,numcnt=0,consonantcnt=0,specialcharcnt=0,spacecnt=0;
		for(int i=0;i<len;i++)
		{
			if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U'||ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
			{
				++vowelcnt;
			}
			else if(ch[i]>='0'&& ch[i]<='9')
			{
				++numcnt;
			}
			else if(ch[i]>='a' && ch[i]<='z')
			{
				++consonantcnt;
			}
			else if(ch[i]==' ')
			{
				++spacecnt;
			}
			else
			{
				++specialcharcnt;
			}
		}
		System.out.println("vowel count is "+vowelcnt);
		System.out.println("number count is "+numcnt);
		System.out.println("consonant count is "+consonantcnt);
		System.out.println("space count is "+spacecnt);
		System.out.println("specialcharacter count is "+specialcharcnt);
		

	}

}
