que7.
package Stringpackage;

public class Stringcasereverse {

	public static void main(String[] args) {
		String s="Hello World";
		System.out.println(s);
		char[] ch=s.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]>=65 && ch[i]<=97)
			{
				ch[i]=(char) (ch[i]+32);
			}
			else
			{
				ch[i]=(char) (ch[i]-32);
			}
		}
		for(int i=0;i<ch.length;i++)
		{
			System.out.print(ch[i]);

		}
          	
	}
}
