que8.
package Stringpackage;

public class Stringreverse {

	public static void main(String[] args) {
		String str="Hello World";
		char [] rslt=str.toCharArray();
		char temp;
		System.out.println(rslt);
		int length=rslt.length;
		for(int i=0;i<length/2;i++)
		{
			temp=rslt[i];
			rslt[i]=rslt[length-i-1];
			rslt[length-i-1]=temp;
		}
		System.out.println(rslt);

	}

}
