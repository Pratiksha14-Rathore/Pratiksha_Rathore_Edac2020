QUE3--
3. Write a program which generates the series 1,4,27,16,125,36 
ANS--
import java.util.Scanner;
class Series
{
Scanner sc=new Scanner(System.in);
int n,i=1;
int res=0;
void setData()
{ n=sc.nextInt(); 
while(i<=n)
{
if(i%2==0)
{
 
res=(int)(Math.pow(i,2));
System.out.println(res);
}
else
{
res=(int)(Math.pow(i,3));
System.out.println(res);
} 
i++;
}

}
public static void main(String args[])
{
Series s=new Series();
s.setData();

}
}