package javax.xml.ws;

public class Dispatch {

}
