package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDB {
	public static Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/productdetails", "root", "edac20");
			return con;

		} catch (Exception ex) {

		}
		return null;
	}

	public static void main(String args[]) {

	}

}
