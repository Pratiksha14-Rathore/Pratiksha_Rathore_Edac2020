package in.edac;

import java.io.PrintWriter;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServlet;

/**
 * web.xml
 * @author HP
 */
public class HelloServlet5 extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			PrintWriter out = response.getWriter();
			out.println("Servlet 5");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}