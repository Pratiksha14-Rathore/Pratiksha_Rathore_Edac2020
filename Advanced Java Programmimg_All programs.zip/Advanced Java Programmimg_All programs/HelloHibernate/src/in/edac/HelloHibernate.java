package in.edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class HelloHibernate {

	public static void main(String[] args) {
		
		
		//how to link java program in hibernate
		
		SessionFactory sessionFactory =new Configuration().configure().buildSessionFactory();
		//normal session org hibernate
		Session session=sessionFactory.openSession();
		System.out.println("Hello Hibernate!!!!!!!!");
		session.close();
		
	}

}
  