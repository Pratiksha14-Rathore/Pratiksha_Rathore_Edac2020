package day5jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * R1. Database Server :: MySQL :: SCHEMA / TABLE 
 * 
 * @author research
 * ASSIGNMENT. 
 * 1. CREAETE SCHEMA PROGRAMMATICALLY
 * 2. CREATE TABLE PROGMATICALLY
 * 
 * Fully Classified Name.
 * Dynamic Loading.
 * 
 * HelloJdbc
 * in.edac.HelloJdbc
 */

public class HelloJdbc {

	public static void main(String[] args) {
		try {
			// Dynamic Loading!! the class Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/practice";
			String user = "root";
			String password = "edac20";

			// Open connection
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("Yes!!! DB Connected!!");

			// Close Connection
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
