package day5jdbc;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class HelloJdbc3 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/practice";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) {
		Connection con=null;
		
		try {
			//Dynamic Loading!! the class Driver
			Class.forName(DB_DRIVER);
			
			//Open Connection
			con=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
			System.out.println("Yesss!!! Database Connected!!!!");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
