package in.edac.dao;

//means we are creating a class using private
//so we have created one class User
// so we created simple user class getter and setter method 
//using Rightclick-source-getter and setter method. and we also created construcur using this 
//we create 2 constuctur paramterized and zero argument consturcter
//why? SO THAT IF I CREATE OBJECT OF USER 5 FILEDS WE HAVE TO SO WE CALL THE METOD IN USERDAO CLASS
//public boolean crateUser2(User user) ye vali method 

public class User {
	private int id;
	private String username;
	private String email;
	private String password;
	private String mobile;
	
	
	
	public User() {
		super();
		
	}
	
	

	public User( String username, String email, String password, String mobile) {
		super();
		
		this.username = username;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	

}
