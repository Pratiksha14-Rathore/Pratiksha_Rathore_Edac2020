package in.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class RegisterDao {
	public static final SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();

	
	
    public  void createUser(User user)
    {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		tx.commit();
		
		session.save(user);
		session.close();
	}
}