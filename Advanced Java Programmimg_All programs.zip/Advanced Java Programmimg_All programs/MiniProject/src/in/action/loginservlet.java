package in.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.dao.LoginDao;
import in.dao.User;



/**
 * Servlet implementation class loginservlet
 */
@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			
			LoginDao dao = new in.dao.LoginDao();
			User user = new User(username, password, null, null);
			boolean check =  dao.authenticateUser(user);
			
			if(check == true) {
				HttpSession session=request.getSession();
				session.setAttribute("my-auth", 1);
				
				response.sendRedirect("/MiniProject/loginhome.jsp");
			} else {
				throw new Exception("Auth Fails");
			}
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
			response.sendRedirect("/MiniProject/login.jsp");
		}
	}
	}


