package in.action;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;  
import java.util.Date; 

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.dao.Payment;
import in.dao.PaymentDao;
import in.dao.RegisterDao;
import in.dao.User;
import java.util.Calendar;

@WebServlet("/Paymentservlet")
public class Paymentservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			
			
		
			
			String cardownername=request.getParameter("username");
			String cardnumber=request.getParameter("cardNumber");
		
			String emonth=	request.getParameter("expiry_month");
			String eyear=request.getParameter(" expiry_year");
			
			
			   
			String cvvno=request.getParameter("cvv");
			
			
			Payment pay=new Payment(cardownername,cardnumber,emonth,eyear,cvvno);
			
			 PaymentDao payment=new  PaymentDao();
			 payment.doPayment(pay);
			
			response.sendRedirect("/MiniProject/Thanks.jsp?q=1");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			response.sendRedirect("/MiniProject/login.jsp?q=0");
		}
	}

}
