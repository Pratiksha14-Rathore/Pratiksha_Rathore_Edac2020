package in.edac;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

//userRepository  will work with user entity id is primary key so uska datattype likha
public interface UserRepository extends JpaRepository<User, Integer>{
	//want to find by username and password
List<User> findByUsername(String username);
	
	User findByUsernameAndPassword(String username, String password);
	
	List<User> findByUsernameOrEmail(String username, String email);
}


