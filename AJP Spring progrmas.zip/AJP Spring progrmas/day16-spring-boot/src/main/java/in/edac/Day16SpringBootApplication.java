package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Day16SpringBootApplication implements CommandLineRunner {
	@Autowired
	private UserRepository userRepository;
	
   //private  DemoManager demoManager;
	public static void main(String[] args) {
		SpringApplication.run(Day16SpringBootApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Hello Spring This is run method!!!!!!");
		//System.out.println(demoManager);
		//create();
		//update();
		//findUpdate();
		//delete();
		//findAllDemo();
		queryDemo();
	}
	//i want to find by username and password
public void queryDemo() {
		
		// List<User> list=  userRepository.findByUsername("pratiksha");
		//list.stream().map(User::getUsername).forEach(System.out::println);
	// User user = userRepository.findByUsernameAndPassword("asdfa", "mumbai");
			// System.out.println(user);
			// System.out.println(user.getUsername());
			
			
			List<User> list = userRepository.findByUsernameOrEmail("adfadfas", "mumbai@gmail.com");
			list.stream().map(User::getUsername).forEach(System.out::println);
		
		
	}
	public void findAllDemo() {
		List<User> list =  userRepository.findAll();
		list.stream().map(User::getUsername).forEach(System.out::println);
	}
	public void delete() {
		userRepository.deleteById(2);
	}
	
	//able to update specific field
	public void findUpdate() {
		User user = userRepository.findById(2).get();
		user.setUsername("MUMBAIIIIIIII");
		
		userRepository.save(user);
	}
	public void update() {
		User user = new User();
		user.setId(2);
		user.setUsername("pratiksha-punam");
		
		
		
		userRepository.save(user);
	}
	public void create() {

	//i want to save an object
			User user=new User("pratiksha","123","prat@gmail.com","549451651");
			userRepository.save(user);

}
}
