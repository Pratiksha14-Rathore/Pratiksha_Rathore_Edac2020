package in.edac;

import org.springframework.stereotype.Component;

@Component
public class DemoManager {
	
	public void sayHi() {
		System.out.println("I am Demo Manager");
	}

}
