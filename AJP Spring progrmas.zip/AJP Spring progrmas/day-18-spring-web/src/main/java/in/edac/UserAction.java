package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class UserAction {
	
	
	/**
	 * for run use this url
	 * http://localhost:8080/
	 * @return
	 */
	@GetMapping("/")
	public String helloworld() {
		
		return "HelloWorld";
		
	}
	/**
	 * http://localhost:8080/1
	 * @return
	 */
	
	@GetMapping("/1")
	public String helloWorldv1() {
		return "helloWorld V1";
	}
	/**
	 * http://localhost:8080/2
	 * @return
	 */
	
	@GetMapping("/2")
	public String helloWorldV2()
	{
		return "helloWorldV2";
	}
	
	

}
