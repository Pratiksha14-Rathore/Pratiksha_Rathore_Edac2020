package in.edac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day18SpringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
