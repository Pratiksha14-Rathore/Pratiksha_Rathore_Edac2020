package in.edac;

public class UserManager {
	public void sayHii() {
		System.out.println("Helloooo!!!!");
	}

}
