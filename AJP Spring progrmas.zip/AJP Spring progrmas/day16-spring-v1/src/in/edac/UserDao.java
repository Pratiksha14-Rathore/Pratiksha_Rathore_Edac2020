package in.edac;

public class UserDao {
	
	//to call thi non static method humne hellospring1 mai call kia without using new keyword using spring framework
	public void sayHi() {
		System.out.println("Helloooo!!!!");
	}

}
